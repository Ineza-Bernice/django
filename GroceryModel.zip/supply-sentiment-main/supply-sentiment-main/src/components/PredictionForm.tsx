
import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { useToast } from "@/components/ui/use-toast";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card";
import { GroceryPredictionInput } from '@/types/model';
import { Info } from 'lucide-react';

interface PredictionFormProps {
  onSubmit: (data: GroceryPredictionInput) => void;
  isLoading: boolean;
}

const PredictionForm: React.FC<PredictionFormProps> = ({ onSubmit, isLoading }) => {
  const { toast } = useToast();
  const [formData, setFormData] = useState<GroceryPredictionInput>({
    stockQuantity: 0,
    reorderLevel: 0,
    reorderQuantity: 0,
    unitPrice: 0,
    inventoryTurnoverRate: 0,
    percentage: 0,
  });

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target;
    setFormData((prev) => ({
      ...prev,
      [name]: parseFloat(value) || 0,
    }));
  };

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    
    // Simple validation to ensure positive values
    for (const [key, value] of Object.entries(formData)) {
      if (value < 0) {
        toast({
          title: "Invalid input",
          description: `${key} should be a positive number.`,
          variant: "destructive",
        });
        return;
      }
    }
    
    onSubmit(formData);
  };

  const formFields = [
    { name: "stockQuantity", label: "Stock Quantity", description: "Current quantity in stock" },
    { name: "reorderLevel", label: "Reorder Level", description: "Threshold to trigger reordering" },
    { name: "reorderQuantity", label: "Reorder Quantity", description: "Quantity to order when restocking" },
    { name: "unitPrice", label: "Unit Price", description: "Price per unit" },
    { name: "inventoryTurnoverRate", label: "Inventory Turnover Rate", description: "How quickly inventory is sold" },
    { name: "percentage", label: "Percentage", description: "Additional factor in percentage" },
  ];

  return (
    <Card className="w-full max-w-md glass-card">
      <CardHeader>
        <CardTitle className="text-xl">Prediction Parameters</CardTitle>
        <CardDescription>Enter the details for inventory prediction</CardDescription>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} id="prediction-form" className="space-y-4">
          {formFields.map((field, index) => (
            <motion.div 
              key={field.name}
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.3, delay: index * 0.05 }}
              className="space-y-2"
            >
              <div className="flex items-center justify-between">
                <Label htmlFor={field.name} className="text-sm font-medium">
                  {field.label}
                </Label>
                <div className="relative group">
                  <Info className="h-4 w-4 text-muted-foreground cursor-help" />
                  <div className="absolute right-0 w-48 p-2 mt-1 text-xs bg-popover text-popover-foreground rounded-md shadow-md opacity-0 invisible group-hover:opacity-100 group-hover:visible transition-opacity">
                    {field.description}
                  </div>
                </div>
              </div>
              <Input
                id={field.name}
                name={field.name}
                type="number"
                step="any"
                value={formData[field.name as keyof GroceryPredictionInput]}
                onChange={handleChange}
                className="w-full transition-all duration-200 focus:ring-2 focus:ring-primary/20"
                placeholder={`Enter ${field.label.toLowerCase()}`}
              />
            </motion.div>
          ))}
        </form>
      </CardContent>
      <CardFooter>
        <Button 
          type="submit" 
          form="prediction-form" 
          className="w-full"
          disabled={isLoading}
        >
          {isLoading ? "Calculating..." : "Predict Inventory"}
        </Button>
      </CardFooter>
    </Card>
  );
};

export default PredictionForm;
