
import React, { ReactNode } from 'react';
import Header from './Header';

interface DashboardLayoutProps {
  children: ReactNode;
}

const DashboardLayout: React.FC<DashboardLayoutProps> = ({ children }) => {
  return (
    <div className="min-h-screen flex flex-col bg-gradient-to-br from-background to-background/95">
      <Header />
      <main className="flex-1 container px-4 py-8 mx-auto max-w-6xl">
        {children}
      </main>
      <footer className="py-4 px-6 text-center text-sm text-muted-foreground border-t border-border/40">
        <p>Grocery Inventory Prediction System © {new Date().getFullYear()}</p>
      </footer>
    </div>
  );
};

export default DashboardLayout;
