
import React from 'react';
import { motion } from 'framer-motion';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { GroceryPredictionResult } from '@/types/model';
import { Check, PackageCheck } from 'lucide-react';

interface PredictionResultProps {
  result: GroceryPredictionResult | null;
}

const PredictionResult: React.FC<PredictionResultProps> = ({ result }) => {
  if (!result) return null;

  return (
    <motion.div
      initial={{ opacity: 0, scale: 0.95 }}
      animate={{ opacity: 1, scale: 1 }}
      transition={{ duration: 0.3 }}
    >
      <Card className="w-full max-w-md bg-gradient-to-br from-card to-card/80 backdrop-blur-sm border border-primary/10 shadow-md overflow-hidden">
        <div className="absolute top-0 left-0 w-full h-1 bg-primary/30" />
        <CardHeader className="pb-2">
          <CardTitle className="flex items-center text-xl space-x-2">
            <PackageCheck className="h-5 w-5 text-primary" />
            <span>Prediction Result</span>
          </CardTitle>
          <CardDescription>Calculated based on your input parameters</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            <div className="flex flex-col items-center justify-center p-4">
              <motion.div 
                initial={{ scale: 0.8 }}
                animate={{ scale: 1 }}
                transition={{ type: "spring", stiffness: 200, damping: 10 }}
                className="w-24 h-24 rounded-full bg-primary/10 flex items-center justify-center mb-2"
              >
                <span className="text-3xl font-semibold text-primary">
                  {result.prediction.toFixed(2)}
                </span>
              </motion.div>
              <span className="text-sm text-muted-foreground">Predicted Inventory</span>
            </div>

            {result.confidence && (
              <div className="rounded-lg bg-secondary/50 p-3 flex items-center space-x-2">
                <div className="rounded-full bg-primary/10 p-1.5">
                  <Check className="h-4 w-4 text-primary" />
                </div>
                <div className="flex-1">
                  <p className="text-xs text-muted-foreground">Confidence Level</p>
                  <p className="text-sm font-medium">{(result.confidence * 100).toFixed(1)}%</p>
                </div>
              </div>
            )}

            {result.message && (
              <div className="rounded-lg bg-secondary/50 p-3">
                <p className="text-sm">{result.message}</p>
              </div>
            )}
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );
};

export default PredictionResult;
