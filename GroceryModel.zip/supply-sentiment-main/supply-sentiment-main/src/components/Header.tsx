
import React from 'react';
import { ShoppingBasket } from 'lucide-react';

const Header = () => {
  return (
    <header className="w-full py-4 px-6 flex items-center justify-between bg-background/95 backdrop-blur-sm border-b border-border/40 sticky top-0 z-50 animate-fade-in">
      <div className="flex items-center space-x-2">
        <ShoppingBasket className="h-6 w-6 text-primary" />
        <h1 className="text-xl font-semibold tracking-tight">Grocery Inventory Predictor</h1>
      </div>
      <div className="text-sm text-muted-foreground">
        Accurate inventory predictions for optimal stock management
      </div>
    </header>
  );
};

export default Header;
