
export interface GroceryPredictionInput {
  stockQuantity: number;
  reorderLevel: number;
  reorderQuantity: number;
  unitPrice: number;
  inventoryTurnoverRate: number;
  percentage: number;
}

export interface GroceryPredictionResult {
  prediction: number;
  confidence?: number;
  message?: string;
}

export interface ApiError {
  error: string;
  details?: string;
}
