
import { GroceryPredictionInput, GroceryPredictionResult, ApiError } from '@/types/model';

const API_URL = 'http://localhost:8000/api';

export async function predictInventory(input: GroceryPredictionInput): Promise<GroceryPredictionResult> {
  try {
    const response = await fetch(`${API_URL}/predict`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(input),
    });

    if (!response.ok) {
      const errorData: ApiError = await response.json();
      throw new Error(errorData.error || 'Failed to get prediction');
    }

    return await response.json() as GroceryPredictionResult;
  } catch (error) {
    console.error('Prediction error:', error);
    if (error instanceof Error) {
      throw error;
    }
    throw new Error('An unknown error occurred');
  }
}
