
import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { useToast } from "@/components/ui/use-toast";
import DashboardLayout from '@/components/DashboardLayout';
import PredictionForm from '@/components/PredictionForm';
import PredictionResult from '@/components/PredictionResult';
import { GroceryPredictionInput, GroceryPredictionResult } from '@/types/model';
import { predictInventory } from '@/services/predictionService';
import { TrendingUp, PackageOpen, TrendingDown } from 'lucide-react';

const Index = () => {
  const { toast } = useToast();
  const [predictionResult, setPredictionResult] = useState<GroceryPredictionResult | null>(null);
  const [isLoading, setIsLoading] = useState(false);

  const handleSubmit = async (data: GroceryPredictionInput) => {
    setIsLoading(true);
    try {
      // In a real application, this would call the API
      // For now, we'll simulate a response
      // const result = await predictInventory(data);
      
      // Simulate API call with a delay
      await new Promise(resolve => setTimeout(resolve, 1200));
      
      // Calculate a simulated prediction based on the input parameters
      // This is just for demonstration until the real API is connected
      const simulatedPrediction = (
        data.stockQuantity * 0.7 + 
        data.reorderLevel * 0.5 + 
        data.reorderQuantity * 0.3 + 
        (data.unitPrice > 0 ? 50 / data.unitPrice : 0) + 
        data.inventoryTurnoverRate * 5 + 
        data.percentage * 0.2
      );
      
      const result: GroceryPredictionResult = {
        prediction: Math.max(0, simulatedPrediction),
        confidence: 0.85,
        message: "Based on the provided parameters, this is the estimated optimal inventory level."
      };
      
      setPredictionResult(result);
      toast({
        title: "Prediction Complete",
        description: "Your inventory prediction has been calculated successfully.",
      });
    } catch (error) {
      console.error(error);
      toast({
        title: "Prediction Failed",
        description: error instanceof Error ? error.message : "An unknown error occurred",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <DashboardLayout>
      <div className="mb-8 text-center max-w-3xl mx-auto">
        <motion.h1 
          className="text-3xl md:text-4xl font-bold mb-3"
          initial={{ opacity: 0, y: -10 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          Grocery Inventory Prediction
        </motion.h1>
        <motion.p 
          className="text-muted-foreground"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ duration: 0.5, delay: 0.2 }}
        >
          Enter your inventory parameters to get accurate predictions for optimal stock levels
        </motion.p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-8 mb-12">
        {[
          { 
            icon: <PackageOpen className="h-8 w-8 text-primary" />, 
            title: "Optimize Stock Levels", 
            description: "Maintain the right inventory balance to reduce costs and meet demand" 
          },
          { 
            icon: <TrendingUp className="h-8 w-8 text-primary" />, 
            title: "Increase Efficiency", 
            description: "Streamline your inventory management process with data-driven insights" 
          },
          { 
            icon: <TrendingDown className="h-8 w-8 text-primary" />, 
            title: "Reduce Waste", 
            description: "Minimize overstock situations and product waste with accurate predictions" 
          }
        ].map((feature, index) => (
          <motion.div
            key={index}
            className="glass-panel rounded-xl p-6 flex flex-col items-center text-center"
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.4, delay: 0.1 + index * 0.1 }}
          >
            <div className="mb-4 rounded-full bg-primary/10 p-3">
              {feature.icon}
            </div>
            <h3 className="text-lg font-semibold mb-2">{feature.title}</h3>
            <p className="text-sm text-muted-foreground">{feature.description}</p>
          </motion.div>
        ))}
      </div>

      <div className="flex flex-col md:flex-row gap-8 items-center md:items-start justify-center mx-auto">
        <motion.div
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.5 }}
        >
          <PredictionForm onSubmit={handleSubmit} isLoading={isLoading} />
        </motion.div>
        
        {predictionResult && (
          <motion.div
            initial={{ opacity: 0, x: 20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.5 }}
          >
            <PredictionResult result={predictionResult} />
          </motion.div>
        )}
      </div>
    </DashboardLayout>
  );
};

export default Index;
