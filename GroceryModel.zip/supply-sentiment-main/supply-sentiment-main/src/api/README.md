
# Grocery Inventory Prediction API

This directory contains the FastAPI backend for the Grocery Inventory Prediction application.

## Setup

1. Make sure you have Python 3.8+ installed.

2. Create a virtual environment:
   ```
   python -m venv venv
   ```

3. Activate the virtual environment:
   - Windows:
     ```
     venv\Scripts\activate
     ```
   - Unix/MacOS:
     ```
     source venv/bin/activate
     ```

4. Install dependencies:
   ```
   pip install -r requirements.txt
   ```

5. Place your trained model in this directory:
   - The `Grocerymodel.pkl` file should be in this directory
   - The model should be compatible with the input parameters defined in the API

## Running the API

Run the FastAPI server:
```
python main.py
```

Or with uvicorn directly:
```
uvicorn main:app --reload --host 0.0.0.0 --port 8000
```

The API will be available at http://localhost:8000

## API Documentation

Once the server is running, you can access the auto-generated documentation:
- Swagger UI: http://localhost:8000/docs
- ReDoc: http://localhost:8000/redoc

## API Endpoints

- `GET /`: Basic health check
- `POST /api/predict`: Get a grocery inventory prediction

## Input Parameters

The prediction endpoint expects the following parameters:
- `stockQuantity`: Current quantity in stock
- `reorderLevel`: Threshold to trigger reordering
- `reorderQuantity`: Quantity to order when restocking
- `unitPrice`: Price per unit
- `inventoryTurnoverRate`: How quickly inventory is sold
- `percentage`: Additional factor in percentage

## Response Format

```json
{
  "prediction": 123.45,
  "confidence": 0.85,
  "message": "Based on the provided parameters, this is the estimated optimal inventory level."
}
```
