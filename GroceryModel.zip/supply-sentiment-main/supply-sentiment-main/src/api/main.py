
from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel, Field
import uvicorn
import pickle
import pandas as pd
import os
from typing import Optional

# Define the model input schema
class GroceryPredictionInput(BaseModel):
    stockQuantity: float = Field(..., gt=0, description="Current quantity in stock")
    reorderLevel: float = Field(..., ge=0, description="Threshold to trigger reordering")
    reorderQuantity: float = Field(..., ge=0, description="Quantity to order when restocking")
    unitPrice: float = Field(..., gt=0, description="Price per unit")
    inventoryTurnoverRate: float = Field(..., ge=0, description="How quickly inventory is sold")
    percentage: float = Field(..., ge=0, le=100, description="Additional factor in percentage")

# Define the model output schema
class GroceryPredictionOutput(BaseModel):
    prediction: float
    confidence: Optional[float] = None
    message: Optional[str] = None

app = FastAPI(
    title="Grocery Inventory Prediction API",
    description="API for predicting grocery inventory levels",
    version="1.0.0"
)

# Add CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # In production, replace with specific origins
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Load the pre-trained model
@app.on_event("startup")
async def load_model():
    global model
    try:
        model_path = os.path.join(os.path.dirname(__file__), "Grocerymodel.pkl")
        with open(model_path, "rb") as f:
            model = pickle.load(f)
    except Exception as e:
        print(f"Error loading model: {str(e)}")
        # For demo purposes, we'll continue without the model
        model = None

@app.get("/")
async def root():
    return {"message": "Grocery Inventory Prediction API is running"}

@app.post("/api/predict", response_model=GroceryPredictionOutput)
async def predict(input_data: GroceryPredictionInput):
    try:
        # If we don't have a model, use a simple calculation
        if model is None:
            # Simulated prediction based on the input parameters
            prediction = (
                input_data.stockQuantity * 0.7 + 
                input_data.reorderLevel * 0.5 + 
                input_data.reorderQuantity * 0.3 + 
                (50 / input_data.unitPrice if input_data.unitPrice > 0 else 0) + 
                input_data.inventoryTurnoverRate * 5 + 
                input_data.percentage * 0.2
            )
            
            return GroceryPredictionOutput(
                prediction=max(0, prediction),
                confidence=0.85,
                message="Based on the provided parameters, this is the estimated optimal inventory level."
            )
        
        # If we have a model, we'd use it like this:
        # Convert input data to DataFrame for prediction
        input_df = pd.DataFrame([{
            "stock_quantity": input_data.stockQuantity,
            "reorder_level": input_data.reorderLevel,
            "reorder_quantity": input_data.reorderQuantity,
            "unit_price": input_data.unitPrice,
            "inventory_turnover_rate": input_data.inventoryTurnoverRate,
            "percentage": input_data.percentage
        }])
        
        # Make prediction using the model
        prediction = model.predict(input_df)[0]
        
        # Get prediction confidence if the model supports it
        confidence = None
        if hasattr(model, "predict_proba"):
            confidence = model.predict_proba(input_df).max()
        
        return GroceryPredictionOutput(
            prediction=float(prediction),
            confidence=confidence,
            message="Prediction based on trained model analysis."
        )
        
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Prediction error: {str(e)}")

if __name__ == "__main__":
    uvicorn.run("main:app", host="0.0.0.0", port=8000, reload=True)
