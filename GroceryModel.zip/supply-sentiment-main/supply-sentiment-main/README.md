
# Grocery Inventory Prediction System

A modern web application for predicting grocery inventory levels based on various parameters.

## Features

- Interactive UI for entering inventory parameters
- Real-time inventory predictions
- Responsive design for desktop and mobile
- FastAPI backend with machine learning model integration

## Project Structure

- `/src` - Frontend React application
  - `/components` - Reusable UI components
  - `/services` - API service layer
  - `/types` - TypeScript type definitions
  - `/pages` - Main application pages
- `/src/api` - FastAPI backend application

## Getting Started

### Frontend Setup

1. Install dependencies:
   ```
   npm install
   ```

2. Start the development server:
   ```
   npm run dev
   ```

3. Open [http://localhost:8080](http://localhost:8080) in your browser.

### Backend Setup

1. Navigate to the backend directory:
   ```
   cd src/api
   ```

2. Follow the instructions in the API README to set up and run the backend server.

## Usage

1. Enter the required inventory parameters in the prediction form:
   - Stock Quantity
   - Reorder Level
   - Reorder Quantity
   - Unit Price
   - Inventory Turnover Rate
   - Percentage

2. Click "Predict Inventory" to get the prediction result.

3. View the predicted inventory level along with confidence information.

## Model Information

The prediction model (`Grocerymodel.pkl`) should be placed in the `/src/api` directory. The model is trained on the Grocery_Inventory.csv dataset and expects the following input features:

- Stock Quantity
- Reorder Level
- Reorder Quantity
- Unit Price
- Inventory Turnover Rate
- Percentage

## Tech Stack

- **Frontend**: React, TypeScript, Tailwind CSS, shadcn/ui
- **Backend**: FastAPI, Python
- **Machine Learning**: scikit-learn (assumed)
- **Data Handling**: pandas
