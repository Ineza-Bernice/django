from django.db import models
from django.core.validators import MinValueValidator
from resourses.models import Resource

class Disaster(models.Model):
    DISASTER_TYPES = [
        ('flood', 'Flood'),
        ('earthquake', 'Earthquake'),
        ('fire', 'Fire'),
        ('storm', 'Storm'),
        ('drought', 'Drought'),
        ('landslide', 'Landslide'),
        ('tsunami', 'Tsunami'),
        ('volcano', 'Volcano'),
    ]

    SEVERITY_CHOICES = [
        (1, 'Low'),
        (2, 'Moderate'),
        (3, 'High'),
        (4, 'Severe'),
        (5, 'Critical'),
    ]

   
    disaster_id = models.AutoField(primary_key=True)  
    type = models.CharField(max_length=50, choices=DISASTER_TYPES)  
    location = models.CharField(max_length=100)  
    date = models.DateField() 
    severity = models.IntegerField(choices=SEVERITY_CHOICES, validators=[MinValueValidator(1)])  
    response = models.TextField()  

   
    reported_by = models.CharField(max_length=50)  
    status = models.CharField(max_length=20, default='active')  

    class Meta:
        db_table = "disasters"  
        verbose_name_plural = "Disasters"  


    def __str__(self):
        return f"{self.type} in {self.location} on {self.date}"
