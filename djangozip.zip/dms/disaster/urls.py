from django.urls import path
from . import views

urlpatterns = [
    path("", views.disaster_list, name="disaster_list"),  
    path("disaster/create/", views.create_disaster, name="create_disaster"), 
    path("update/<pk>/", views.update_disaster, name="update_disaster"),  
    path("delete/<pk>/", views.delete_disaster, name="delete_disaster"), 
]

