# disaster/forms.py
from django import forms
from .models import Disaster
from resourses.models import Resource

class DisasterForm(forms.ModelForm):
    resources_needed = forms.ModelMultipleChoiceField(
        queryset=Resource.objects.all(),
        widget=forms.CheckboxSelectMultiple,
        required=False
    )

    class Meta:
        model = Disaster
        fields = '__all__'


