from django.contrib.auth.decorators import login_required
from django.shortcuts import render, redirect, get_object_or_404
from .models import Disaster
from .forms import DisasterForm
from django.core.paginator import Paginator
from django.contrib import messages  

def index(request):
    return render(request, "index.html")


@login_required
def disaster_list(request):
    disaster_queryset = Disaster.objects.all()
    paginator = Paginator(disaster_queryset, 10)
    page_number = request.GET.get('page', 1)
    disasters_page = paginator.get_page(page_number)
    return render(request, "disasters/disaster_list.html", {"disasters": disasters_page})



def create_disaster(request):
    if request.method == "POST":
        form = DisasterForm(request.POST)
        if form.is_valid():
            form.save()
            messages.success(request, "Disaster created successfully.")
            return redirect("disaster_list")
        else:
            messages.error(request, "Error creating disaster. Please check the form.")
    else:
        form = DisasterForm()
    return render(request, "disasters/create_disaster.html", {"form": form})


@login_required
def update_disaster(request, pk):
    disaster = get_object_or_404(Disaster, pk=pk)
    if request.method == "POST":
        form = DisasterForm(request.POST, instance=disaster)
        if form.is_valid():
            form.save()
            messages.success(request, "Disaster updated successfully.")
            return redirect("disaster_list")
        else:
            messages.error(request, "Error updating disaster. Please check the form.")
    else:
        form = DisasterForm(instance=disaster)
    return render(request, "disasters/update_disaster.html", {"form": form})


@login_required
def delete_disaster(request, pk):
    disaster = get_object_or_404(Disaster, pk=pk)
    if request.method == "POST":
        disaster.delete()
        messages.success(request, "Disaster deleted successfully.")
        return redirect("disaster_list")
    return render(request, "disasters/delete_disaster.html", {"disaster": disaster})
