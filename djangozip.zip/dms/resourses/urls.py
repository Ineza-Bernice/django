from django.urls import path
from . import views

urlpatterns = [
    path('', views.index, name='index'),  # Home page with resource listing
    path('resources/', views.resource_list, name='resource_list'),  # List of resources
    path('resources/create/', views.create_resource, name='create_resource'),  # Create resource
    path('resources/update/<int:pk>/', views.update_resource, name='update_resource'),  # Update resource
    path('resources/delete/<int:pk>/', views.delete_resource, name='delete_resource'),  # Delete resource

    # API URLs
    path('api/resources/', views.ResourceListView.as_view(), name='resource_api_list'),  # API for listing resources
    path('api/resources/<int:pk>/', views.ResourceDetailView.as_view(), name='resource_api_detail'),  # API for resource details
]
