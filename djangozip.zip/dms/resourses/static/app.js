const searchInput = document.getElementById('searchInput');
const tableRows = document.querySelectorAll('#resouresTable tbody tr'); 

const rowsPerPage = 10; 
let currentPage = 1;

searchInput.addEventListener('input', (e) => {
  const searchTerm = e.target.value.toLowerCase();
  tableRows.forEach((row) => {
    const rowText = row.textContent.toLowerCase();
    if (rowText.includes(searchTerm)) {
      row.style.display = ''; 
    } else {
      row.style.display = 'none'; 
    }
  });
});
