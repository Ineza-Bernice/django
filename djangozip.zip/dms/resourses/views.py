from django.contrib.auth.decorators import login_required
from django.shortcuts import render, get_object_or_404, redirect
from .models import Resource
from .forms import ResourceForm
from django.core.paginator import Paginator
from rest_framework.views import APIView
from rest_framework.response import Response
from rest_framework import status

# Index view to display all resources with pagination
def index(request):
    resources = Resource.objects.all()  # Get all resources
    paginator = Paginator(resources, 10)  # Paginate the resources (10 per page)
    page_number = request.GET.get('page')  # Get the page number from GET request
    page_obj = paginator.get_page(page_number)  # Get the page object based on the page number
    
    # Prepare lists of resource names and quantities for printing
    resource_names = [resource.name for resource in resources]
    resource_quantities = [resource.quantity for resource in resources]
    print(resource_names, resource_quantities)

    # Render the index page with the resources and pagination
    return render(request, 'index.html', {
        'page_obj': page_obj,
        'resource_names': resource_names,
        'resource_quantities': resource_quantities
    })

# Resource list view to show a paginated list of all resources
def resource_list(request):
    resources = Resource.objects.all()  # Get all resources
    paginator = Paginator(resources, 10)  # Paginate the resources (10 per page)
    page_number = request.GET.get('page')  # Get the page number from GET request
    page_obj = paginator.get_page(page_number)  # Get the page object based on the page number
    
    # Render the resource list page
    return render(request, "resources/resource_list.html", {"page_obj": page_obj})

# Create new resource view (using POST to submit the form)
def create_resource(request):
    if request.method == "POST":  # If the form is submitted via POST
        form = ResourceForm(request.POST)  # Create form with POST data
        if form.is_valid():  # If the form data is valid
            form.save()  # Save the new resource to the database
            return redirect("resource_list")  # Redirect to the resource list page after saving
    else:  # If it's a GET request (i.e., the form is being displayed)
        form = ResourceForm()  # Create a new blank form
    return render(request, "resources/create_resource.html", {"form": form})

# Update an existing resource view
def update_resource(request, pk):
    resource = get_object_or_404(Resource, pk=pk)  # Get the resource by its primary key (pk)
    if request.method == "POST":  # If the form is submitted via POST
        form = ResourceForm(request.POST, instance=resource)  # Pre-fill the form with the existing resource data
        if form.is_valid():  # If the form data is valid
            form.save()  # Save the updated resource to the database
            return redirect("resource_list")  # Redirect to the resource list page after saving
    else:  # If it's a GET request (i.e., the form is being displayed for editing)
        form = ResourceForm(instance=resource)  # Create a form pre-filled with the resource data
    return render(request, "resources/update_resource.html", {"form": form})

# Delete a resource view (using POST to confirm deletion)
def delete_resource(request, pk):
    resource = get_object_or_404(Resource, pk=pk)  # Get the resource by its primary key (pk)
    if request.method == "POST":  # If the form is submitted via POST
        resource.delete()  # Delete the resource from the database
        return redirect("resource_list")  # Redirect to the resource list page after deletion
    return render(request, "resources/delete_resource.html", {"resource": resource})

# Optionally, you can also define API views for creating, updating, and deleting resources via API.
# These views can be used to access the resources via RESTful endpoints.
class ResourceListView(APIView):
    def get(self, request):
        resources = Resource.objects.all()
        resource_data = [{"id": resource.id, "name": resource.name, "quantity": resource.quantity} for resource in resources]
        return Response(resource_data, status=status.HTTP_200_OK)
    
    def post(self, request):
        form = ResourceForm(request.data)
        if form.is_valid():
            form.save()
            return Response({"message": "Resource created successfully!"}, status=status.HTTP_201_CREATED)
        return Response({"errors": form.errors}, status=status.HTTP_400_BAD_REQUEST)

class ResourceDetailView(APIView):
    def get(self, request, pk):
        resource = get_object_or_404(Resource, pk=pk)
        resource_data = {"id": resource.id, "name": resource.name, "quantity": resource.quantity}
        return Response(resource_data, status=status.HTTP_200_OK)
    
    def put(self, request, pk):
        resource = get_object_or_404(Resource, pk=pk)
        form = ResourceForm(request.data, instance=resource)
        if form.is_valid():
            form.save()
            return Response({"message": "Resource updated successfully!"}, status=status.HTTP_200_OK)
        return Response({"errors": form.errors}, status=status.HTTP_400_BAD_REQUEST)
    
    def delete(self, request, pk):
        resource = get_object_or_404(Resource, pk=pk)
        resource.delete()
        return Response({"message": "Resource deleted successfully!"}, status=status.HTTP_204_NO_CONTENT)

