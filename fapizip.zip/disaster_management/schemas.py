from fastapi import FastAPI
from pydantic import BaseModel, EmailStr
from typing import Optional

app = FastAPI()

# -------------------
# Pydantic Models
# -------------------

# Base User model
class UserBase(BaseModel):
    id: Optional[int]  # Optional for cases like POST requests
    name: str
    email: EmailStr

    class Config:
        orm_mode = True

# User creation model
class UserCreate(BaseModel):
    name: str
    email: EmailStr
    password: str

# Base Incident model
class IncidentBase(BaseModel):
    id: int
    description: str

# Base Resource model
class ResourceBase(BaseModel):
    id: int
    name: str
    type: str
    quantity: int

    class Config:
        orm_mode = True  # Enable ORM mode for easy conversion

# Resource creation model
class ResourceCreate(BaseModel):
    name: str
    type: str
    quantity: int
    incident_id: Optional[int] = None  # Assuming the resource is linked to an incident

# -------------------
# Routes
# -------------------

# Route to create a new user
@app.post("/users")
async def create_user(user: UserCreate):
    # In real applications, insert the user into the database here
    return {
        "message": "User created successfully",
        "user": user
    }

# Route to create a new resource
@app.post("/resources")
async def create_resource(resource: ResourceCreate):
    # In real applications, insert the resource into the database here
    return {
        "message": "Resource created successfully",
        "resource": resource
    }
