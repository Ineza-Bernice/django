from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from database import SessionLocal

from schemas import ResourceBase
from typing import List
from models import Resource
router = APIRouter(prefix="/resources", tags=["Resources"])

def get_db():
    db = SessionLocal()
    try:
        yield db
    finally:
        db.close()

@router.post("/", response_model=ResourceBase)
def create_resource(resource: ResourceBase, db: Session = Depends(get_db)):
    new_resource = Resource(**resource.dict())
    db.add(new_resource)
    db.commit()
    db.refresh(new_resource)
    return new_resource

# Route to get all resources
@router.get("/", response_model=List[ResourceBase])
def get_resources(db: Session = Depends(get_db)):
    return db.query(Resource).all()
