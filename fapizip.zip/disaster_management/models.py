from sqlalchemy import Column, Integer, String, Text, ForeignKey, DateTime
from sqlalchemy.orm import relationship
from database import Base
from datetime import datetime

class User(Base):
    __tablename__ = "users"
    
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String, nullable=False)
    email = Column(String, unique=True, nullable=False)
    hashed_password = Column(String, nullable=False)

   
    incidents = relationship("Incident", back_populates="user")

class Incident(Base):
    __tablename__ = "incidents"
    
    id = Column(Integer, primary_key=True, index=True)
    title = Column(String, nullable=False)
    description = Column(Text, nullable=False)
    location = Column(String, nullable=False)
    date_reported = Column(DateTime, default=datetime.utcnow)
    status = Column(String, default="pending")  
    
    user_id = Column(Integer, ForeignKey("users.id"))
    
  
    user = relationship("User", back_populates="incidents")
    resources = relationship("Resource", back_populates="incident")

class Resource(Base):
    __tablename__ = "resources"
    
    id = Column(Integer, primary_key=True, index=True)
    name = Column(String, nullable=False)
    type = Column(String, nullable=False)
    quantity = Column(Integer, nullable=False)

   
    incident_id = Column(Integer, ForeignKey("incidents.id"))

  
    incident = relationship("Incident", back_populates="resources")


Incident.resources = relationship("Resource", back_populates="incident")

