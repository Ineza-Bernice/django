from fastapi import FastAPI
from routers.users import router as userrouter
from routers.incidents import router as incidentrouter
from routers.resources import router as resourcesrouter
from utils import fetch_api_data
from database import engine, Base

app = FastAPI()


app.include_router(userrouter, prefix="/users", tags=["Users"])
app.include_router(incidentrouter, prefix="/incidents", tags=["Incidents"])
app.include_router(resourcesrouter, prefix="/resources", tags=["Resources"])


@app.get("/fetch_data")
def fetch_data():
    data = fetch_api_data()
    return {
        "users": data["users"].to_dict() if data["users"] is not None else None,
        "resources": data["resources"].to_dict() if data["resources"] is not None else None,
        "incidents": data["incidents"].to_dict() if data["incidents"] is not None else None,
    }


Base.metadata.create_all(bind=engine)
