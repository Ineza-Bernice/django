import requests
import pandas as pd

def fetch_api_data():
    """
    Fetch data from external APIs for Users, Resources, and Incidents.
    Returns:
        dict: A dictionary containing Pandas DataFrames for users, resources, and incidents.
    """
    try:
        # Fetch Users API
        users_api = requests.get('http://127.0.0.1:8000/users_api')
        users_api.raise_for_status()
        users_api_data = users_api.json()
        
        # Fetch Resources API
        resources_api = requests.get('http://127.0.0.1:8000/resources_api')
        resources_api.raise_for_status()
        resources_api_data = resources_api.json()
        
        # Fetch Incidents API
        incidents_api = requests.get('http://127.0.0.1:8000/incidents_api')
        incidents_api.raise_for_status()
        incidents_api_data = incidents_api.json()
        
        # Convert to Pandas DataFrames
        users_df = pd.DataFrame(users_api_data['users'])
        resources_df = pd.DataFrame(resources_api_data['resources'])
        incidents_df = pd.DataFrame(incidents_api_data['incidents'])

        return {
            "users": users_df,
            "resources": resources_df,
            "incidents": incidents_df,
        }
    except requests.exceptions.RequestException as e:
        print(f"Error fetching data from API: {e}")
        return {"users": None, "resources": None, "incidents": None}
